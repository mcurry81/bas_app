<?php
session_start();
$_SESSION['loggedIn'] = "false";
header("Location: main_login.php");
?>