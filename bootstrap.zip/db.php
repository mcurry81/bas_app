 <?php
    $username = "amaninde_user";
    $password = "Password01";
    $hostname = "localhost";
    ?>